var oracle = require("oracledb");
var fs = require('fs');
var JSONStream = require('JSONStream');

require("dotenv").config({ silent: true });

const connectData = {
  user: "USER_ED",
  password: process.env.BANNER_PSWD,
  connectString: "dbprod.banner.ramapo.edu:1521/rcnj"
};

oracle.getConnection(connectData, function(err, connection) {
  if (err) {
    console.log(`- Banner:  Oracle connection error.`);
    console.log(err);
    return;
  }
  var json = JSONStream.stringify();
  var outstream = fs.createWriteStream('reg-dump.json');
  json.pipe(outstream);
  // TXRCSCT - Course
  // TXRSREG - Registration data
  var q = "SELECT * FROM TXRSREG";
  var stream = connection.queryStream(q, [], {fetchArraySize:150});
  stream.pipe(json);
  /*stream.on('data', function(data) {
	console.log(data);

  });
  stream.on('end', function() {
	console.log("All done");
  });*/
  /*connection.execute(q, [], function(err, results) {
    console.log(err);
    console.log(JSON.stringify(results, null, 2));
    if (!err) connection.close();
  });
   */

  // TXRSREG_SID - Course Registration
  //
});
