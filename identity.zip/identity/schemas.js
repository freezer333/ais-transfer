exports.init = function init(mongoose) {
  var users = mongoose.model('users', {
    username :String,
    name: {
        first: String,
        last: String
    },
    email: String,
    phone: String, 
    student: Boolean,
    faculty: Boolean,
    staff : Boolean, 
    roles :[String], 
    majors : [String], 
    minors : [String], 
    rNumber : String,
    address : {
            street1 : String,
            street2 : String,
            city : String,
            state: String,
            zip : String,
            country : String
        }
  }, "users");

  exports.Users = users;
}