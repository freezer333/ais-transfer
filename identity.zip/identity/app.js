require("dotenv").config({ silent: true });

/*

-  Requirements

Redis must be installed and running locally.
Requires Mongo to be installed and running locally (even in production - API keys).

*/

const path = require("path");
const http = require("http");
const https = require("https");
const fs = require("fs");
const express = require("express");
const app = express();

const busboy = require("express-busboy");
const helmet = require("helmet");
const bunyan = require("bunyan");
const bformat = require("bunyan-format");
const formatOut = bformat({ outputMode: "short" });
const port = process.env.SERVER_PORT || 3000;

////////////////////////////////////////////////////
// Basic express configuration
////////////////////////////////////////////////////
app.set("port", port);

busboy.extend(app);

app.use(helmet());

////////////////////////////////////////////////////
// Logging configuration
////////////////////////////////////////////////////
var mainlog = bunyan.createLogger({
  name: "identity-service",
  stream: formatOut,
  level: process.env.LOG_LEVEL
});
app.use(function(req, res, next) {
  req.log = mainlog;
  next();
});

////////////////////////////////////////////////////
// Database & Provider configuration
////////////////////////////////////////////////////
const redis = require("redis");
const client = redis.createClient();
app.locals.redis = client;

// Mongo is used for storing keys in development and production
var MongoClient = require("mongodb").MongoClient;
var keys_url = process.env.KEY_BASE;
MongoClient.connect(keys_url, function(err, db) {
  if (err) {
    mainlog.fatal(
      "Could not connect to mongo database for key access.  Ensure mongo is running and the KEY_BASE environment variable is set correctly"
    );
    process.exit();
  }
  mainlog.info("Connected to keystore database at " + keys_url);
  app.locals.keys = db.collection("keys");
});

// Mongo is only used for users when testing, or developing
// it holds test user data.
if (process.env.NODE_ENV != "production") {
  const mongoose = require("mongoose");
  const schemas = require("./schemas");
  mongoose.connect(
    "mongodb://localhost/banner",
    { auto_reconnect: true },
    function(err, res) {
      if (err) {
        mainlog.fatal("Could not connect to mongo database at localhost");
        process.exit();
      } else {
        mainlog.info(
          "Connected to mongo database at localhost (used for development only)"
        );
        schemas.init(mongoose);
        var test_banner = require("./profiles/testing");
        var bannerdb = new test_banner(schemas.Users);
        var provider = new (require("./profiles/provider"))(client, bannerdb);
        app.locals.banner = provider;

        var auth = require("./authenticators/fixed");
        app.locals.authenticator = new auth("password", provider);
      }
    }
  );
} else {
  const bannerdb = require("./profiles/banner");
  const ldap = require("./authenticators/ldap");
  const banner = require("./profiles/provider");
  const provider = new banner(client, new bannerdb(mainlog));

  app.locals.banner = provider;
  app.locals.authenticator = new ldap(mainlog);
  mainlog.info("Configured data sources using LDAP and Banner (Production)");
}

////////////////////////////////////////////////////
// Route configuration
////////////////////////////////////////////////////
var routes = require("./routes");
app.use("/", routes);

app.use(function(err, req, res, next) {
  console.log(err);
  console.log(err.stack);
  mainlog.fatal(err);
  res.status(500).send("Identity fell down.");
});

////////////////////////////////////////////////////
// Startup
////////////////////////////////////////////////////
var server = http.createServer(app);

var boot = function() {
  if (process.env.NODE_ENV == "production") {
    var options = {
      key: fs.readFileSync("/etc/pki/tls/private/STAR_ramapo_edu.key"),
      cert: fs.readFileSync("/etc/pki/tls/certs/STAR_ramapo_edu.crt")
    };

    console.log(
      new Date().toString() +
        " - Started https on port 443, http on port 80 (production)"
    );
    var http_forward = express();

    http_forward.get("*", function(req, res, next) {
      try {
        console.log(
          new Date().toString() + " - Redirected request to https - " + req.url
        );
        res.redirect("https://" + req.get("host") + req.url);
      } catch (err) {
        console.log(new Date().toString() + " - Redirected failed");
        res.redirect("https://" + req.get("host"));
      }
    });
    http.createServer(http_forward).listen(80);
    https.createServer(options, app).listen(443);
  } else {
    server.listen(port, function() {
      mainlog.info("Identity service startup -- %s", process.env.NODE_ENV);
    });
  }
};

var shutdown = function() {
  server.close();
};

if (require.main === module || process.env.NODE_ENV == "production") {
  boot();
} else {
  console.info("Running app as a module");
  exports.boot = boot;
  exports.shutdown = shutdown;
  exports.port = port;
  //exports.db = function() { return app.locals.admin_db }
}
