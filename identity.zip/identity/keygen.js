require('dotenv').config({silent: true});
var uuid = require('node-uuid');
var parseArgs = require('minimist');
var args = parseArgs(process.argv.slice(2));

var MongoClient = require('mongodb').MongoClient;
var url = process.env.KEY_BASE;

var usage = function() {
    console.log("Usage\n===============================");
    console.log("-- $ node keygen.js create -n <app_name>");
    console.log("-- $ node keygen.js revoke -n <app_name>");
    console.log("-- $ node keygen.js show -n <app_name>");
    process.exit()
}

var print = function(token) {
    console.log('='.repeat(80));
    console.log("Name:  " + token.name );
    console.log('='.repeat(80));
    console.log(token.api_key);
}

if ( args._.length < 1 ) {
    usage();
}

var action = args._[0];
if ( action != "create" && action != "revoke" && action != "show") {
    usage();
}

var name = args.n;
if (!name) {
    usage();
}

MongoClient.connect(url, function(err, db) {
    var keys = db.collection('keys');

    if (action == "create") {
        var api_key = [uuid.v4(), uuid.v4(), uuid.v4(), uuid.v4()].join("");
        console.log("Identity key created successfully.");
    
        var entry = {
            name : name,
            key : api_key
        };
        keys.insert(entry, function(err, results) {
            if ( err ) {
                console.log(err);
            }
            else {
                print({name:name, api_key: api_key});
            }
            db.close();
        });
    }
    else if (action == "show") {
        keys.find({name:name}).toArray(function(err, docs) {
            if ( docs && docs.length > 0 ) {
                print({name:name, api_key: docs[0].key});
            }
            else {
                console.log("No API key found for " + name);
            }
            db.close();
        })
    }
    else if (action == "revoke") {
        keys.deleteMany({name:name}, null, function(err, result) {
            console.log("Identity key for " + name + " revoked.");
            db.close();
        });
    }
});
