"use strict";
var express = require("express");
const logger = require("./logger");
var router = express.Router();

router.use(function(req, res, next) {
  var name = req.body.api_name || req.headers["api-name"];
  var key = req.body.api_key || req.headers["api-key"];
  var keys = req.app.locals.keys;
  if (name && key) {
    keys.find({ name: name }).toArray(function(err, docs) {
      var result = docs && docs.length > 0 ? docs[0] : undefined;
      if (result) {
        if (result.key == key) next();
        else {
          console.log("Authentication credentials are invalid");
          return res.status(403).send("Authentication failed.");
        }
      } else {
        console.log("Authentication credentials are invalid");
        return res.status(403).send("Authentication failed.");
      }
    });
  } else {
    console.log("Authentication credentials are missing");
    return res.status(403).send("Authentication failed.");
  }
});

router.post("/fetch", function(req, res) {
  var banner = req.app.locals.banner;
  var usernames = [];
  var result = "";

  if (!req.body.username) {
    logger.debug(`/fetch called with no username field.`);
    logger.debug(JSON.stringify(req.body, null, 2));
    res.status(404).send("Not found");
    return;
  }
  if (typeof req.body.username === "object") {
    logger.debug(`/fetch called with username as object`);
    logger.debug(JSON.stringify(req.body.username, null, 2));
    result = Object.keys(req.body.username).map(function(key) {
      return req.body.username[key];
    });
  } else if (Array.isArray(req.body.username)) {
    logger.debug(`/fetch called with username as array`);
    logger.debug(JSON.stringify(req.body.username, null, 2));
    result = req.body.username;
  } else {
    try {
      logger.debug(`/fetch called as value, parsing`);
      logger.debug(req.body.username);
      result = [req.body.username];
      logger.debug(` -- successfully parsed ${result}`);
    } catch (e) {
      logger.debug(` -- could not be parsed`);
      logger.debug(e);
      result = "";
    }
  }

  if (Array.isArray(result)) {
    usernames = result;
  } else {
    usernames = req.body.username.split(",").map(function(user) {
      return user.trim();
    });
  }
  logger.debug(`Fetching usernames`);
  logger.debug(usernames);

  if (usernames && usernames.length > 1) {
    logger.debug(`Getting list of usernames from banner`);
    banner.getUsers(usernames, function(err, result) {
      if (!result && !result.success) {
        console.log("ERROR");
        logger.error(`Users could not be found`);
        logger.error(result);
        res.status(404).send("Not found");
        return;
      } else {
        logger.debug(`Returning users`);
        logger.debug(JSON.stringify(result.users, 2, null));
        res.status(200).send(result.users);
        return;
      }
    });
  } else if (usernames && usernames.length == 1) {
    logger.debug(
      `Getting single username from banner provider - ${usernames[0]}`
    );
    banner.getUser(usernames[0], function(err, result) {
      if (!result.success) {
        logger.error(`User could not be found`);
        logger.error(result);
        res.status(404).send("Not found");
      } else {
        logger.debug(`Returning single user`);
        logger.debug(JSON.stringify(result.user, 2, null));
        res.status(200).send(result.user);
      }
    });
  } else {
    logger.debug(
      `Returning 404 because no usernames were specified in fetch request`
    );
    res.status(404).send("Not found");
  }
});

router.post("/auth", function(req, res) {
  var auth = req.app.locals.authenticator;
  console.log("Authenticating " + req.body.username);
  auth.check(req.body.username, req.body.password, function(err, result) {
    res.status(200).send(JSON.stringify(result));
  });
});

router.get("/isup", function(req, res) {
  res.status(200).send("Service is up.");
});

//router.use("/courses", require("./courses"));

module.exports = router;
