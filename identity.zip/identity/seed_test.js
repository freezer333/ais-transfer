const mongoose = require("mongoose");
const schemas = require("./schemas");
mongoose.connect(
  "mongodb://localhost/banner",
  { auto_reconnect: true },
  async function(err, res) {
    if (err) {
      console.log("Could not connect to mongo database at localhost");
      process.exit();
    } else {
      console.log(
        "Connected to mongo database at localhost (used for development only)"
      );
      schemas.init(mongoose);
      var Users = schemas.Users;

      var users = require("./seed.json");

      for (let i = 0; i < users.length; i++) {
        const u = new Users(users[i]);
        console.log(` - Seeding ${u.username}`);
        await u.save();
      }

      console.log("Saved all test data");
    }
  }
);
