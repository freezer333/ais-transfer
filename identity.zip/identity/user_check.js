require('dotenv').config({ silent: true });

const bunyan = require('bunyan');

const redis = require("redis");
const client = redis.createClient

const mainlog = bunyan.createLogger({ name: 'identity-debug', level: process.env.LOG_LEVEL });

const bannerdb = require('./profiles/banner')
const db = new bannerdb(mainlog);

const ldap = require('./authenticators/ldap')
const banner = require('./profiles/provider')
const provider = new banner(client, db);

db.getUsers(['mgeneux'], function (err, result) {
    console.log("FROM DATABASE --");
    console.log(err)
    console.log(result);
    console.log("-- FROM DATABASE");
})

provider.getUsers(['mgeneux'], function (err, result) {
    console.log("FROM PROVIDER --");
    console.log(err)
    console.log(result);
    console.log("-- FROM PROVIDER");
})